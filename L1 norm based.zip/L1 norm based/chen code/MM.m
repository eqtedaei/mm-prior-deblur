% Written by Amir Eqtedaei 2023
% L1 regularized Max-min prior

function [ output_img,A ] = MM( img,patch_size )

[M,N] = size(img);

max_tv_mat = Max_matrix(img,patch_size);
min_tv_mat = Min_matrix(img,patch_size);

output_img =  (max_tv_mat - min_tv_mat)*img(:);
output_img = reshape(output_img,[M,N]);

A = (max_tv_mat - min_tv_mat);
end

