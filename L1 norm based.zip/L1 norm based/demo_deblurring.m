clc;
clear;
close all;
addpath(genpath('whyte_code'));
addpath(genpath('cho_code'));
addpath(genpath('chen code'));
opts.prescale = 1; %%downsampling
opts.xk_iter = 5; %% the iterations
opts.gamma_correct = 1.0;
opts.k_thresh = 20;

filename = 'image\test3_blur_55.png'; opts.kernel_size = 55;  
saturation = 0;lambda_lmg =4e-3; lambda_grad =4e-3; opts.gamma_correct = 1;
lambda_tv = 0.001; lambda_l0 = 1e-3; weight_ring = 1;

%===================================

y = imread(filename);
% y = y(3:end-2,3:end-2,:);
% y = imfilter(y,fspecial('gaussian',5,1),'same','replicate'); 
isselect = 0; %false or true
if isselect ==1
    figure, imshow(y);
    %tips = msgbox('Please choose the area for deblurring:');
    fprintf('Please choose the area for deblurring:\n');
    h = imrect;
    position = wait(h);
    close;
    B_patch = imcrop(y,position);
    y = (B_patch);
else
    y = y;
end
if size(y,3)==3
    yg = im2double(rgb2gray(y));
else
    yg = im2double(y);
end
tStart = tic;
[kernel, interim_latent] = blind_deconv(yg, lambda_lmg, lambda_grad, opts);
toc(tStart)
%% Algorithm is done!
%% ============Non-blind deconvolution ((Just use text deblurring methods))====================%%
y = im2double(y);
%% Final Deblur: 
if ~saturation
    Latent = ringing_artifacts_removal(y, kernel,lambda_tv,lambda_l0, 1);
else
    %% 2. Whyte's deconvolution method (For saturated images)
    Latent = whyte_deconv(y, kernel);
end
figure; imshow(Latent)
k = kernel/max(kernel(:));

imwrite(k,['results\' filename(7:end-4) '_kernel.png']);
imwrite(Latent,['results\' filename(7:end-4) '_result.png']);
imwrite(interim_latent,['results\' filename(7:end-4) '_interim_result.png']);

