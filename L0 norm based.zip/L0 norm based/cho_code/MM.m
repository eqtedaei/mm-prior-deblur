% Written by Amir Eqtedaei 2023
% L0 regularized Max-min prior

function [ output_img ] = MM( img,patch_size )

[M,N] = size(img);

output_img = ordfilt2(img,patch_size^2,ones(patch_size),'symmetric')-ordfilt2(img,1,ones(patch_size),'symmetric'); %M-m

end

