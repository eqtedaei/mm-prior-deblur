clc;
clear;
close all;
addpath(genpath('image'));
addpath(genpath('whyte_code'));
addpath(genpath('cho_code'));
opts.prescale = 1; %%downsampling
opts.xk_iter = 5; %% the iterations
opts.gamma_correct = 1.0;
opts.k_thresh = 20;
%% Note:
%% lambda_tv, lambda_l0, weight_ring are non-necessary, they are not used in kernel estimation.
%%

filename = 'image\im1_kernel1_img.png'; opts.kernel_size = 19;  saturation = 0;
lambda_dark = 4e-3; lambda_grad = 4e-3;
lambda_tv = 0.01; lambda_l0 = 2e-3; weight_ring = 1;

%%
% filename = 'image\street_cars_blurry.jpg'; opts.kernel_size = 53;  saturation = 1;
% lambda_dark = 4e-3; lambda_grad = 4e-3;%opts.gamma_correct = 2.2;

%%
% filename = 'image\my_test_car6.png'; opts.kernel_size = 95;  saturation = 1;
% lambda_dark = 4e-3; lambda_grad = 4e-3;opts.gamma_correct = 1.0;

%%
% filename = 'image\IMG_0650_small_patch.png'; opts.kernel_size = 65;  saturation = 1;
% lambda_dark = 4e-3; lambda_grad = 4e-3;opts.gamma_correct = 1.0;
% lambda_tv = 0.001; lambda_l0 = 5e-4; weight_ring = 1;

%% For the first figure

% filename = 'image\eccv3_blurred.png'; opts.kernel_size = 23;  saturation = 0;
% lambda_dark = 4e-3; lambda_grad = 4e-3;opts.gamma_correct = 1;
% lambda_tv = 0.001; lambda_l0 = 5e-4; weight_ring = 1;

% filename = 'image\my_shufa_image_blur_121.png'; opts.kernel_size = 111;  saturation = 0;
% lambda_dark = 4e-3; lambda_grad = 4e-3;opts.gamma_correct = 2.2;
% lambda_tv = 0.0002; lambda_l0 = 1e-4; weight_ring = 1;

% filename = 'image\color_patch_blur_99.png'; opts.kernel_size = 99;  saturation = 0;
% lambda_dark = 4e-3; lambda_grad = 4e-3;%opts.gamma_correct = 2.2;
% lambda_tv = 0.002; lambda_l0 = 2e-4; weight_ring = 1;
% 
% filename = 'image\0015_blur65.png'; opts.kernel_size =67;  saturation = 0;
% lambda_dark = 4e-3; lambda_grad = 4e-3;opts.gamma_correct = 2.2;
% lambda_tv = 0.001; lambda_l0 = 2e-4; weight_ring = 1;
% 
% filename = 'image\Majid_Samii.jpg'; opts.kernel_size = 85;  saturation = 0;
% lambda_dark = 4e-3; lambda_grad = 4e-3;opts.gamma_correct = 1;
% lambda_tv = 0.0001; lambda_l0 = 1e-4; weight_ring = 1;

% filename = 'image\blurred_cho.png'; opts.kernel_size = 23;  saturation = 0;
% lambda_dark = 4e-3; lambda_grad = 4e-3;%opts.gamma_correct = 2.2;
% lambda_tv = 0.0002; lambda_l0 = 2e-4; weight_ring = 1;

% filename = 'image\new_test_img12_blur_129.png'; opts.kernel_size = 101;  saturation = 0;
% lambda_dark = 4e-3; lambda_grad = 4e-3;%opts.gamma_correct = 2.2;
% lambda_tv = 0.001; lambda_l0 = 2e-4; weight_ring = 1;

%===================================
y = imread(filename);
% y = y(3:end-2,3:end-2,:);
% y = imfilter(y,fspecial('gaussian',5,1),'same','replicate'); 
isselect = 0; %false or true
if isselect ==1
    figure, imshow(y);
    %tips = msgbox('Please choose the area for deblurring:');
    fprintf('Please choose the area for deblurring:\n');
    h = imrect;
    position = wait(h);
    close;
    B_patch = imcrop(y,position);
    y = (B_patch);
else
    y = y;
end
if size(y,3)==3
    yg = im2double(rgb2gray(y));
else
    yg = im2double(y);
end
tic;
[kernel, interim_latent] = blind_deconv(yg, lambda_dark, lambda_grad, opts);
toc
%% Algorithm is done!
%% ============Non-blind deconvolution ((Just use text deblurring methods))====================%%
y = im2double(y);
%% Final Deblur: 
if ~saturation
    %% 1. TV-L2 denoising method
    Latent = ringing_artifacts_removal(y, kernel, lambda_tv, lambda_l0, weight_ring);
else
    %% 2. Whyte's deconvolution method (For saturated images)
    Latent = whyte_deconv(y, kernel);
end
figure; imshow(Latent)
%%
k = kernel - min(kernel(:));
k = k./max(k(:));
imwrite(k,['results\' filename(7:end-4) '_kernel.png']);
imwrite(Latent,['results\' filename(7:end-4) '_result.png']);
imwrite(interim_latent,['results\' filename(7:end-4) '_interim_result.png']);
%%
%% ============Use Cho et al., ICCV 11 for non-blind deconvolution (For saturated images???)====================%%
%deblurred0 = deconv_outlier(y, kernel, 5/255, 0.003);
