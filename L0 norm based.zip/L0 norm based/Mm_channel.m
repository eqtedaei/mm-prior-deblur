function [Jd, J_indexd,Jb, J_indexb] = Mm_channel(I, patch_size)

[M, N, C] = size(I);
Jd = zeros(M, N); % Create empty matrix for J
Jb = zeros(M, N); % Create empty matrix for J
J_indexd = zeros(M, N); % Create empty index matrix
J_indexb = zeros(M, N); % Create empty index matrix
if ~mod(numel(patch_size),2) % if even number
    error('Invalid Patch Size: Only odd number sized patch supported.');
end

% pad original image
%I = padarray(I, [floor(patch_size./2) floor(patch_size./2)], 'symmetric');
I = padarray(I, [floor(patch_size./2) floor(patch_size./2)], 'replicate');

% Compute the dark channel 
for m = 1:M
        for n = 1:N
            patch = I(m:(m+patch_size-1), n:(n+patch_size-1),:);
            
            tmpd = min(patch, [], 3);
            [tmp_vald, tmp_idxd] = min(tmpd(:));
            Jd(m,n) = tmp_vald;
            J_indexd(m,n) = tmp_idxd;
            
            tmpb = max(patch, [], 3);
            [tmp_valb, tmp_idxb] = max(tmpb(:));
            Jb(m,n) = tmp_valb;
            J_indexb(m,n) = tmp_idxb;
        end
end

end



